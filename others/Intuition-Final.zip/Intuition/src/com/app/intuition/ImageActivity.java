package com.app.intuition;

import com.users.Tag;

import net.intuition.APIConnection;
import android.os.AsyncTask;
import android.os.Bundle;
import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Intent;
import android.graphics.Typeface;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

/**
 * Activity showing tag
 * User must answer with yes, no, or skip the tag
 * @author Developer's Rift
 *
 */
public class ImageActivity extends Activity {

	private ProgressDialog pDialog;
	private TextView tagView;
	private Button buttonYes, buttonNo, buttonSkip;
	private boolean init = true;


	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_image);
		
		tagView = (TextView) findViewById(R.id.textViewTag);
		buttonYes = (Button) findViewById(R.id.buttonYes);
		buttonNo = (Button) findViewById(R.id.buttonNo);
		buttonSkip = (Button) findViewById(R.id.buttonSkip);

		// Setting Listeners
		buttonYes.setOnClickListener(yesAction);
		buttonNo.setOnClickListener(noAction);
		buttonSkip.setOnClickListener(skipAction);

		// Create transition for activity
		this.overridePendingTransition(R.anim.alpha_open_transition, R.anim.alpha_close_transition);

		// If first initialization
		if(init){
			new GetNewTag().execute();
			init = false;
		}
	}

	// Listener for YES button
	private OnClickListener yesAction = new OnClickListener() {
		@Override
		public void onClick(View v) {
			new RateTag(tagView.getText().toString(), 1).execute();
		}
	};

	// Listener for NO button
	private OnClickListener noAction = new OnClickListener() {
		@Override
		public void onClick(View v) {
			new RateTag(tagView.getText().toString(), -1).execute();
		}
	};

	// Listener for SKIP button
	private OnClickListener skipAction = new OnClickListener() {
		@Override
		public void onClick(View v) {
			new RateTag(tagView.getText().toString(), 0).execute();
		}
	};

	
	private class GetNewTag extends AsyncTask<String, String, String> {
		private Tag t;

		@Override
		protected void onPreExecute() {
			super.onPreExecute();
			
			// Show progress dialog
			pDialog = new ProgressDialog(ImageActivity.this);
			pDialog.setMessage("Chargement en cours ...");
			pDialog.setIndeterminate(false);
			pDialog.setCancelable(false);
			pDialog.show();

		}

		@Override
		protected String doInBackground(String... args) {
			t = APIConnection.getNewTag();

			return null;
		}

		@Override
		protected void onPostExecute(String file_url) {
			// Set font.ttf to TextView's Tag
			Typeface titleFont = Typeface.createFromAsset(getAssets(),"fonts/font.ttf");
			tagView.setTypeface(titleFont);
			tagView.setText(t.getName());

			// Set Background color
			RelativeLayout layout = (RelativeLayout)findViewById(R.id.layoutImage);
			layout.setBackgroundColor(t.getColor());
			
			pDialog.dismiss();
		}

	}

	private class RateTag extends AsyncTask<String, String, String> {
		private String tag;
		private int value;
		private boolean success = false;

		/**
		 * 
		 * @param tag 
		 * @param value 1 : positive, 0 : skipped, -1 : negative
		 */
		public RateTag(String tag, int value){
			this.tag = tag;
			this.value = value;
		}

		@Override
		protected void onPreExecute() {
			super.onPreExecute();
			
			// Show progress dialog
			pDialog = new ProgressDialog(ImageActivity.this);
			pDialog.setMessage("Chargement en cours ...");
			pDialog.setIndeterminate(false);
			pDialog.setCancelable(false);
			pDialog.show();

		}

		@Override
		protected String doInBackground(String... args) {
			success = APIConnection.rateTag(tag, value);

			return null;
		}

		@Override
		protected void onPostExecute(String file_url) {
			if (!success)
				Toast.makeText(ImageActivity.this, "Un probl�me est survenu.", Toast.LENGTH_SHORT).show();

			// Verify if a product is selected
			new GetProducts().execute();
		}

	}

	private class GetProducts extends AsyncTask<String, String, String> {
		private boolean success = false;

		@Override
		protected void onPreExecute() {
			super.onPreExecute();

		}

		@Override
		protected String doInBackground(String... args) {
			success = APIConnection.getProducts();
			return null;
		}

		@Override
		protected void onPostExecute(String file_url) {
			pDialog.dismiss();
			// Success = false -> no products found
			if (!success){
				new GetNewTag().execute();
			}
			else { // Show products
				Intent intent = new Intent(getApplicationContext(), ProductInformationsActivity.class);
				startActivity(intent);
				finish();
			}
		}

	}

}
