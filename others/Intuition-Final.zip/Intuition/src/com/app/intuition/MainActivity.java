package com.app.intuition;

import com.users.ProductList;

import android.os.Bundle;
import android.app.Activity;
import android.content.Intent;

/**
 * Launcher activity
 * @author Developer's Rift
 *
 */
public class MainActivity extends Activity {

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		
		// Init list
		ProductList.initList();
		
		Intent intent = new Intent(getApplicationContext(), ImageActivity.class);

		startActivity(intent);
		this.finish();

	}

}
