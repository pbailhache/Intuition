package com.users;

import android.graphics.Color;
import android.util.Log;

/**
 * Tag defined by a name and a color
 * @author Developer's Rift
 *
 */
public class Tag {
	
	private String name;
	private int color;
	
	public Tag(String name, String color){
		this.name = name;
		createColor(color);
	}
	
	/**
	 * Transforms color string "#XXXXXX" to int color value
	 * @param color
	 */
	private void createColor(String color){
		Log.i("Color", color);
		// Color : "XX XX XX"
		this.color = Color.argb(255, Integer.valueOf(color.substring(0,2), 16), Integer.valueOf(color.substring(2,4), 16), Integer.valueOf(color.substring(4,6), 16));
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getColor() {
		return color;
	}


}
